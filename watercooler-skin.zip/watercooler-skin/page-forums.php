<?php include("header.php"); ?>

<?php include("inc-sidebar-left.php"); ?>

<!-- begin main -->
<main role="main">

	<!-- begin -->
	<section class="page-content">

		<h1>Forums</h1>
						
		<p>Aliquam erat volutpat. Vivamus rhoncus dictum urna, at feugiat ligula pretium eu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
			
		<h2>All-Staff Forum</h2>
		<img src="http://placehold.it/225x125" alt="#" class="righty">
		<p>Aliquam erat volutpat. Vivamus rhoncus dictum urna, at feugiat ligula pretium eu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
		<span class="button" role="button"><a href="#">Get started</a></span>

		<hr>

		<h2>Ottawa Team Forum</h2>
		<img src="http://placehold.it/225x125" alt="#" class="righty">
		<p>Aliquam erat volutpat. Vivamus rhoncus dictum urna, at feugiat ligula pretium eu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
		<span class="button" role="button"><a href="#">Get started</a></span>

		<hr>

		<h2>U.S. Team Forum</h2>
		<img src="http://placehold.it/225x125" alt="#" class="righty">
		<p>Aliquam erat volutpat. Vivamus rhoncus dictum urna, at feugiat ligula pretium eu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
		<span class="button" role="button"><a href="#">Get started</a></span>

		<hr>

		<h2>U.K. Forum</h2>
		<img src="http://placehold.it/225x125" alt="#" class="righty">
		<p>Aliquam erat volutpat. Vivamus rhoncus dictum urna, at feugiat ligula pretium eu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
		<span class="button" role="button"><a href="#">Get started</a></span>
		
	</section><!-- / -->
		
</main><!-- /main -->

<?php include("sidebar.php"); ?>

<?php include("footer.php"); ?>