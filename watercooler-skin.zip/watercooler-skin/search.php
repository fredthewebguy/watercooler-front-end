<?php include("header.php"); ?>

<?php include("inc-sidebar-left.php"); ?>

<!-- begin main -->
<main role="main">

<!-- begin page content -->
	<section class="post-archive search-results">

		<h1>Search results : <span>query term</span></h1>

		<?php include("inc-all-cats.php"); ?>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<h2><a href="post.php">I'm Chris Morrison and I approve this message!</a></h2>

		<?php include("inc-paginate-search.php"); ?>

	</section><!-- /page content -->	
		
</main><!-- /main -->

<?php include("sidebar.php"); ?>

<?php include("footer.php"); ?>