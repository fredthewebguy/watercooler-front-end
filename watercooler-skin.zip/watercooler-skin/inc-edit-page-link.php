<!-- begin page edit link -->
<div class="cpt-title edit-page-link">
	<a href="#"><i class="icon-pencil"></i>Edit this</a>
</div><!-- /page edit link -->