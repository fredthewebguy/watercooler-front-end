<?php include("header.php"); ?>

<?php include("inc-sidebar-left.php"); ?>

<!-- begin main -->
<main role="main">

	<!-- begin -->
	<section class="page-content">

		<h1>Page title</h1>
						
		<p>Aliquam erat volutpat. Vivamus rhoncus dictum urna, at feugiat ligula pretium eu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p>
			
		
	</section><!-- / -->
		
</main><!-- /main -->

<?php include("sidebar.php"); ?>

<?php include("footer.php"); ?>