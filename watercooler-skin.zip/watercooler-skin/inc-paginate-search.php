<!-- begin pagination -->
<div class="paginate">
	<a href="#">Previous results</a>
	<a href="#">Next results</a>
</div><!-- /pagination -->