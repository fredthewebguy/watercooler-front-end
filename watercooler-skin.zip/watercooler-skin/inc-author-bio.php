<!--begin author bio -->
<div class="author-bio">
	<a href="#" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
	<span class="author-name">About the author</span>
	<p>Praesent commodo leo et efficitur iaculis. Praesent lacinia orci in nisi lacinia tempor. Proin iaculis lacus eget lorem aliquet, ac congue ex sodales.</p>
	<span class="button" role="button"><a href="#">View profile</a></span>
	<span class="button" role="button"><a href="#">All articles by Chris</a></span>
</div><!-- /auhor bio -->