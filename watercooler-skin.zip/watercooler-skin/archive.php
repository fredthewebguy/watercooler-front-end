<?php include("header.php"); ?>

<?php include("inc-sidebar-left.php"); ?>

<!-- begin main -->
<main role="main">

<!-- begin page content -->
	<section class="post-archive">

		<h1>News Archive</h1>

		<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<!-- begin article snippet -->
			<div class="post-snippet">
				<a href="post.php" title="Name Here"><img src="images/chris.jpg" alt="#"></a>
				<div class="post-snippet-title">
					<h3><a href="post.php">I'm Chris Morrison and I approve this message!</a></h3>
					<span>
						<i class="icon-user"></i>
						<a href="author.php">Chris Morrison</a>
						&nbsp;&nbsp;
						<i class="icon-calendar"></i>
						Wednesday, April 4, 1973
						&nbsp;&nbsp;
						<i class="icon-chat"></i>
						<a href="#">0 comments</a>
					</span>
				</div>
			</div><!-- /article snippet -->

			<?php include("inc-paginate.php"); ?>

	</section><!-- /page content -->	
		
</main><!-- /main -->

<?php include("sidebar.php"); ?>

<?php include("footer.php"); ?>