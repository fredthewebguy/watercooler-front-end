<!-- begin pagination -->
<div class="paginate">
	<a href="#">Newer articles</a>
	<a href="#">Older articles</a>
</div><!-- /pagination -->