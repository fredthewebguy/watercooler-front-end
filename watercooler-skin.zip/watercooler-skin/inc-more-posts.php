<!-- begin more-posts -->
<aside class="more-posts">
	<h2>Also in the news...</h2>
	<h3><a href="#">I'm Chris Morrison and I approve this message!</a></h3>
	<h3><a href="#">I'm Chris Morrison and I approve this message!</a></h3>
	<h3><a href="#">I'm Chris Morrison and I approve this message!</a></h3>
	<!--<span class="button" role="button"><a href="#">News archive</a></span>-->
</aside><!-- /comments -->