<!-- begin extras -->
<aside class="extras">
	<span class="button" role="button"><a href="#">All articles by Fred</a></span>
	<span class="button" role="button"><a href="#">View Fred's profile</a></span>
</aside><!-- /extras -->