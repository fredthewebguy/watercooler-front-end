	<!-- begin footer -->
	<footer>
		&copy;2017 Agility PR Solutions
		&nbsp;&nbsp;&middot;&nbsp;&nbsp;
		An Innodata Company
	</footer><!-- /footer -->

</div><!-- /page wrapper -->

<!-- js -->
<script src="js/jquery-latest.js"></script>
<script src="js/pace.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>