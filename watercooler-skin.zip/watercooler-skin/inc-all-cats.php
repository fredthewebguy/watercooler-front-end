<!-- begin post cats -->
<div class="post-cats all-cats">
	<i class="icon-tags"></i>
	<ul>
	<li><a href="#">News</a></li>
	<li><a href="#">Ottawa Office News</a></li>
	<li><a href="#">Category</a></li>
	<li><a href="#">Marketing</a></li>
	<li><a href="#">Community</a></li>
	<li><a href="#">CSR</a></li>
	<li><a href="#">Social Committee</a></li>
	<li><a href="#">UK Office News</a></li>
	<li><a href="#">US Office News</a></li>
	<li><a href="#">Resources</a></li>
	<li><a href="#">Tools</a></li>
	<li><a href="#">Success Stories</a></li>
	<li><a href="#">Team Building</a></li>
</ul>
</div><!-- /post cats -->