<?php include("header-login.php"); ?>

<!-- begin login wrapper -->
<section class="login-wrapper register-page">

	<h1>Create your Watercooler account</h1>

	<p>You <strong>must</strong> be an employee of Agility PR Solututions, Innodata Inc., or an Innodata subsidiary to use this platform.</p>

	
	<div>
		<h2>Register Your Account</h2>
	</div>

	<div>
		<h2>Create Your Profile</h2>
	</div>
	
</section><!-- /login wrapper -->

<?php include("footer-login.php"); ?>