<!-- begin post cats -->
<div class="post-cats">
	<i class="icon-tags"></i>
	<ul>
	<li><a href="#">News</a></li>
	<li><a href="#">Ottawa News</a></li>
	<li><a href="#">Category</a></li>
</ul>
</div><!-- /post cats -->